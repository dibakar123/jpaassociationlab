package com.jpaproj.app;

import com.jpaproj.dao.AssocaitionImpl;
import com.jpaproj.dao.Association;

public class ClientTestForAssociation {

	public static void main(String[] args) {
		Association association = new AssocaitionImpl();
		// association.addOneToOneMethodUni();
		//association.addOneToOneMethodBi();
		//association.addOneToManyMethod();
		association.addManyToManyMethod();
		//association.addAuthorBooks();
	}

}
