package com.jpaproj.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import com.jpaproj.entity.Author;
import com.jpaproj.entity.Book;
import com.jpaproj.entity.Booking;
import com.jpaproj.entity.Flight;
import com.jpaproj.entity.Instructor;
import com.jpaproj.entity.Instructor2;
import com.jpaproj.entity.InstructorDetail;
import com.jpaproj.entity.InstructorDetail2;
import com.jpaproj.entity.Laptop;
import com.jpaproj.entity.Student;


public class AssocaitionImpl implements Association{

	public void addOneToOneMethodUni() {
		Instructor instructor = new Instructor();
		instructor.setFirstName("Dibakar2");
		
		InstructorDetail instructorDetail = new InstructorDetail();
		instructorDetail.setYoutubeChannel("http://www.youtube1.com");
		
		instructor.setInstructorDetail(instructorDetail);
		
		EntityManagerFactory emf= JPAUtil.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(instructor);
		em.persist(instructorDetail); // with cascade this is not required
		em.getTransaction().commit();
		
	}

	public void addOneToOneMethodBi() {
		Instructor2 instructor = new Instructor2();
		instructor.setFirstName("Dibakar2");
		
		InstructorDetail2 instructorDetail = new InstructorDetail2();
		instructorDetail.setYoutubeChannel("http://www.youtube1.com");
		
		instructorDetail.setInstructor(instructor);
		instructor.setInstructorDetail(instructorDetail);
		
		EntityManagerFactory emf= JPAUtil.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(instructor);
		//em.persist(instructorDetail); // with cascade this is not required
		em.getTransaction().commit();
		
	}

	public void addOneToManyMethod() {
		Flight flight = new Flight();
		flight.setFlightid("F12");
		flight.setAirline("GoAir");
		flight.setSource("Del");
		flight.setDestination("Mum");
		
		Booking booking1 = new Booking();
		booking1.setEmailid("ddd@yy.com");
		booking1.setName("Rajat Dey");
				
		Booking booking2 = new Booking();
		booking2.setEmailid("aadd@yy.com");
		booking2.setName("Rajat Dey");
				
		flight.getBookinglist().add(booking1);
		flight.getBookinglist().add(booking2);	
		
		EntityManagerFactory emf= JPAUtil.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(flight);
		em.persist(booking1);  //with cascade this is not required
		em.persist(booking2);  //with cascade this is not required
		em.getTransaction().commit();
	}
	public void addManyToManyMethod() {
		Laptop laptop = new Laptop(); 	
		laptop.setLid(101);	laptop.setLname("Dell");
		Laptop laptop1 = new Laptop(); 	
		laptop1.setLid(102);	laptop1.setLname("Hp");
		
        Student s = new Student();  
        s.setName("Ram"); s.setRollno(1);   s.setMarks(50);
        s.getLaptop().add(laptop);  s.getLaptop().add(laptop1);
        
        Student s1 = new Student();  
        s1.setName("Rama"); s1.setRollno(2);   s1.setMarks(55);
        s1.getLaptop().add(laptop);  
        
        laptop.getStudent().add(s);
        laptop.getStudent().add(s1);
        laptop1.getStudent().add(s);
        
        
        EntityManagerFactory emf= JPAUtil.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(s);
		em.persist(s1);
		em.getTransaction().commit();
	}
	
	public void addAuthorBooks() {
		Book book1 = new Book(); book1.setBid(100); book1.setBname("C");
		Book book2 = new Book(); book2.setBid(200); book2.setBname("C++");
		Book book3 = new Book(); book3.setBid(300); book3.setBname("Java");
		Author author1 = new Author(); author1.setAid(1); author1.setAname("Rabi");
		author1.getBooks().add(book1);
		author1.getBooks().add(book2);
		Author author2 = new Author(); author2.setAid(1); author1.setAname("kant");
		author2.getBooks().add(book3);
		EntityManagerFactory emf= JPAUtil.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(author1);
		em.persist(author2);
		em.getTransaction().commit();
	}
}
