package com.jpaproj.dao;

public interface Association {
    public void addOneToOneMethodUni();
    public void addOneToOneMethodBi();
    public void addOneToManyMethod();
    public void addManyToManyMethod();
    
    public void addAuthorBooks();
}
