package com.jpaproj.entity;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity(name = "Account")
//@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public abstract class Account {
@Id
private Long id;
private String owner;
private double balance;

// setter & getter
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getOwner() {
	return owner;
}
public void setOwner(String owner) {
	this.owner = owner;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}

@Override
public String toString() {
	return "Account [id=" + id + ", owner=" + owner + ", balance=" + balance + "]";
}
public Account() {
	super();
}

}
