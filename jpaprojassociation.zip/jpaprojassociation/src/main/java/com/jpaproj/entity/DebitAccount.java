package com.jpaproj.entity;
import javax.persistence.Entity;

@Entity(name="DebitAccount")
public class DebitAccount extends Account {
private double overdraftFee;
// setter & getter

public double getOverdraftFee() {
	return overdraftFee;
}

public void setOverdraftFee(double overdraftFee) {
	this.overdraftFee = overdraftFee;
}

public DebitAccount() {
	super();
}

@Override
public String toString() {
	return super.toString()+"\nDebitAccount [overdraftFee=" + overdraftFee + "]";
}

}