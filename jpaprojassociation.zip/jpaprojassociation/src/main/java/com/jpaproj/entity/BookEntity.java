package com.jpaproj.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="books")
public class BookEntity {
@Id
private int isbn;
private String title;
private int price;
@ManyToMany(mappedBy = "bookList")
private List<AuthorEntity> authorList;


public int getIsbn() {
	return isbn;
}
public void setIsbn(int isbn) {
	this.isbn = isbn;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
@Override
public String toString() {
	return "BookEntity [isbn=" + isbn + ", title=" + title + ", price=" + price + "]";
}

}
