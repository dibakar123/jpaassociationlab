package com.jpaproj.entity;
import javax.persistence.Entity;

@Entity(name="CreditAccount")
public class CreditAccount extends Account {
private double creditLimit;
// setter & getter

public double getCreditLimit() {
	return creditLimit;
}

public void setCreditLimit(double creditLimit) {
	this.creditLimit = creditLimit;
}

public CreditAccount() {
	super();
}

@Override
public String toString() {
	return super.toString()+"\nCreditAccount [creditLimit=" + creditLimit + "]";
}

}